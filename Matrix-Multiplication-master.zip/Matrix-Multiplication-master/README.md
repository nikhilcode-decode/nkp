# Matrix-Multiplication
### Information:

- Matrix Multiplication is based on java with gui using swing.
- _Inside dist folder contain jar file_

### Features:

- Multiplying by matrix
- Multiplying by scaler
- Get delta value

Screenshots:
1. Home 

![image](https://user-images.githubusercontent.com/22257930/88180576-34e11080-cc4b-11ea-9091-6938d2407dd0.png)

2. Create matrix -> Click on new matrix

![image](https://user-images.githubusercontent.com/22257930/88180769-7e316000-cc4b-11ea-99b5-062803655507.png)

3. Add values

![image](https://user-images.githubusercontent.com/22257930/88180843-973a1100-cc4b-11ea-9e8c-73598efb8dbf.png)

Developed by: **Sahil Janbandhu**




